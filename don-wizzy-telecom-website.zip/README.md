# Don Wizzy Telecom Website

Upload these files to the root of a GitHub repository:

- `index.html` — website structure
- `styles.css` — responsive styling
- `script.js` — virtual-number selector, price preview, mobile menu and demo forms

## GitHub Pages

After uploading, go to **Settings → Pages** in the repository.

Choose **Deploy from a branch**, select the `main` branch and `/ (root)`, then save.

Your website will be published through GitHub Pages.

### Important

The number selector and contact form are front-end demos. They do not process real payments, provision real phone numbers, or send emails until connected to a backend/API.
