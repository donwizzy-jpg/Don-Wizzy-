const data=[
{country:"United States",numbers:["+1 (415) 555-0218","+1 (212) 555-0173","+1 (310) 555-0147"],areas:["New York (212)","Los Angeles (310)","Chicago (312)","San Francisco (415)"],carriers:["Twilio","T-Mobile","Verizon"],services:["Virtual Phone Numbers","SMS Verification","Business Communication","Global Calling"],price:29},
{country:"United Kingdom",numbers:["+44 20 7946 0958","+44 20 3287 4814","+44 20 3455 9012"],areas:["London (020)","Manchester (0161)","Birmingham (0121)"],carriers:["O2","EE","Vodafone"],services:["Virtual Phone Numbers","SMS Verification","Business Communication","Digital Marketing Tools"],price:34},
{country:"Canada",numbers:["+1 (416) 555-0190","+1 (604) 555-0134","+1 (647) 555-0211"],areas:["Toronto (416)","Vancouver (604)","Montreal (514)"],carriers:["Bell","Rogers","Telus"],services:["Virtual Phone Numbers","SMS Verification","Business Communication","Global Calling"],price:31},
{country:"Australia",numbers:["+61 2 5550 0197","+61 3 5550 4012","+61 8 5550 1724"],areas:["Sydney (02)","Melbourne (03)","Perth (08)"],carriers:["Telstra","Optus","Vodafone"],services:["Virtual Phone Numbers","eSIM","Business Communication","Global Calling"],price:38},
{country:"Germany",numbers:["+49 30 5555 0188","+49 69 5555 4022","+49 151 5555 9051"],areas:["Berlin (030)","Frankfurt (069)","Munich (089)"],carriers:["Telekom","Vodafone","O2"],services:["Virtual Phone Numbers","SMS Verification","Global Calling","Business Communication"],price:33},
{country:"United Arab Emirates",numbers:["+971 4 555 0931","+971 2 555 8470","+971 6 555 4278"],areas:["Dubai (04)","Abu Dhabi (02)","Sharjah (06)"],carriers:["Etisalat","du","Virgin Mobile"],services:["Virtual Phone Numbers","Business Communication","eSIM","Digital Marketing Tools"],price:43},
{country:"Singapore",numbers:["+65 6550 0921","+65 6550 3318","+65 6550 4882"],areas:["Central (65)","West (65)","East (65)"],carriers:["SingTel","StarHub","M1"],services:["Virtual Phone Numbers","SMS Verification","Global Calling","Business Communication"],price:41},
{country:"Japan",numbers:["+81 3 5550 1189","+81 6 5550 2124","+81 45 5550 3497"],areas:["Tokyo (03)","Osaka (06)","Yokohama (045)"],carriers:["docomo","au","SoftBank"],services:["Virtual Phone Numbers","SMS Verification","Business Communication","eSIM"],price:46}
];

const country=document.querySelector("#countrySelect"),phone=document.querySelector("#phoneSelect"),service=document.querySelector("#serviceSelect"),area=document.querySelector("#areaCodeSelect"),carrier=document.querySelector("#carrierSelect"),advanced=document.querySelector("#advancedToggle"),price=document.querySelector("#priceValue");

function fill(select,items,label){select.innerHTML=`<option value="">${label}</option>`;items.forEach(x=>{const o=document.createElement("option");o.value=x;o.textContent=x;select.appendChild(o)})}
data.forEach(x=>{const o=document.createElement("option");o.value=x.country;o.textContent=x.country;country.appendChild(o)});

function update(){
 const d=data.find(x=>x.country===country.value);
 if(!d){fill(phone,[],"Choose a number");fill(service,[],"Choose a service");fill(area,[],"Choose an area code");fill(carrier,[],"Choose a carrier");price.textContent="$29.00";return}
 fill(phone,d.numbers,"Choose a number");fill(service,d.services,"Choose a service");fill(area,d.areas,"Choose an area code");fill(carrier,d.carriers,"Choose a carrier");calculate();
}
function calculate(){
 const d=data.find(x=>x.country===country.value);let amount=d?d.price:29;
 const premiums={"SMS Verification":8,"eSIM":12,"Global Calling":15,"Business Communication":18,"Digital Marketing Tools":10};
 amount+=(premiums[service.value]||0);if(advanced.checked)amount+=12;if(area.value)amount+=6;if(carrier.value)amount+=4;
 price.textContent=`$${amount.toFixed(2)}`;
}
country.addEventListener("change",update);[service,area,carrier,advanced].forEach(x=>x.addEventListener("change",calculate));
advanced.addEventListener("change",()=>{area.disabled=!advanced.checked;carrier.disabled=!advanced.checked});
area.disabled=true;carrier.disabled=true;

document.querySelector("#numberForm").addEventListener("submit",e=>{e.preventDefault();if(!country.value||!phone.value||!service.value){alert("Please complete the required selections.");return}alert(`Demo selection: ${phone.value} for ${service.value}. No purchase was made.`)});
document.querySelector("#contactForm").addEventListener("submit",e=>{e.preventDefault();alert("Thank you. This demo form is ready to be connected to a real email or backend service.")});

const menu=document.querySelector(".mobile-menu"),toggle=document.querySelector(".menu-toggle");
toggle.addEventListener("click",()=>{const open=toggle.getAttribute("aria-expanded")==="true";toggle.setAttribute("aria-expanded",String(!open));menu.classList.toggle("open")});
menu.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>menu.classList.remove("open")));
